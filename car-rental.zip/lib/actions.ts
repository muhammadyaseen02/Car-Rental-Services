"use server"

import type { BookingRequest } from "./types"
import { cars } from "./cars"

export async function submitBookingRequest(data: BookingRequest) {
  // Simulate a delay to mimic server processing
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // In a real application, you would:
  // 1. Validate the data
  // 2. Store it in a database
  // 3. Send email notifications
  // 4. Return a success/error response

  // For now, we'll just log the data and return a success response
  console.log("Booking request received:", {
    ...data,
    car: cars.find((car) => car.id === data.carId)?.name,
  })

  // Simulate success
  return { success: true, message: "Booking request submitted successfully" }
}

