export interface Car {
  id: string
  name: string
  shortDescription: string
  description: string
  capacity: number
  ratePerDay: number
  features: string[]
  image: string
}

export interface BookingRequest {
  name: string
  email: string
  phone: string
  carId: string
  pickupDate: Date
  returnDate: Date
  message?: string
}

