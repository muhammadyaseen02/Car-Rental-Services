import Image from "next/image"
import Link from "next/link"
import { CarCard } from "@/components/car-card"
import { BookingForm } from "@/components/booking-form"
import { cars } from "@/lib/cars"
import { ContactInfo } from "@/components/contact-info"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-40 w-full border-b bg-background">
        <div className="container flex items-center h-16 space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex items-center gap-2">
            <Image
              src="/placeholder.svg?height=40&width=40"
              width={40}
              height={40}
              alt="Hampi Tours & Travels Logo"
              className="rounded-md"
            />
            <span className="text-xl font-bold">Hampi Tours & Travels</span>
          </div>
          <nav className="hidden sm:flex items-center space-x-6 text-sm font-medium">
            <Link href="#cars" className="transition-colors hover:text-primary">
              Our Cars
            </Link>
            <Link href="#about" className="transition-colors hover:text-primary">
              About Us
            </Link>
            <Link href="#booking" className="transition-colors hover:text-primary">
              Book Now
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-[url('/placeholder.svg?height=600&width=1200')] bg-cover bg-center">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-white drop-shadow-md">
                  Explore Hampi in Comfort and Style
                </h1>
                <p className="mx-auto max-w-[700px] text-white text-lg md:text-xl drop-shadow-md">
                  Premium car rental services for tourists and travelers in the historic city of Vijayanagara (Hampi)
                </p>
              </div>
              <div className="space-x-4">
                <Link
                  href="#cars"
                  className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  View Our Fleet
                </Link>
                <Link
                  href="#booking"
                  className="inline-flex h-10 items-center justify-center rounded-md border border-input bg-background px-8 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  Book Now
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section id="cars" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Fleet</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Choose from our range of comfortable and well-maintained vehicles for your journey
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mt-8">
              {cars.map((car) => (
                <CarCard key={car.id} car={car} />
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  About Hampi Tours & Travels
                </h2>
                <p className="text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  We are a premier car rental service based in the historic city of Vijayanagara (Hampi). With years of
                  experience in the tourism industry, we provide reliable, comfortable, and affordable transportation
                  solutions for tourists and travelers.
                </p>
                <p className="text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our fleet of well-maintained vehicles and professional drivers ensure that your journey through the
                  beautiful landscapes and historic sites of Hampi is comfortable and memorable.
                </p>
              </div>
              <ContactInfo />
            </div>
          </div>
        </section>

        <section id="booking" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Book Your Ride</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Fill out the form below to inquire about availability or make a booking
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-2xl mt-8">
              <BookingForm />
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © {new Date().getFullYear()} Hampi Tours & Travels. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link href="#" className="text-sm underline underline-offset-4">
              Terms of Service
            </Link>
            <Link href="#" className="text-sm underline underline-offset-4">
              Privacy Policy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

