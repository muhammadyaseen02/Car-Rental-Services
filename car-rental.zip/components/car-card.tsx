"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Car } from "@/lib/types"
import { useRouter } from "next/navigation"

interface CarCardProps {
  car: Car
}

export function CarCard({ car }: CarCardProps) {
  const router = useRouter()

  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-video">
        <Image src={car.image || "/placeholder.svg"} alt={car.name} fill className="object-cover" />
      </div>
      <CardHeader>
        <CardTitle>{car.name}</CardTitle>
        <CardDescription>{car.shortDescription}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-2">
          <div className="flex flex-wrap gap-1">
            {car.features.map((feature, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {feature}
              </Badge>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex flex-col">
              <span className="text-muted-foreground">Capacity</span>
              <span className="font-medium">{car.capacity} Persons</span>
            </div>
            <div className="flex flex-col">
              <span className="text-muted-foreground">Rate</span>
              <span className="font-medium">₹{car.ratePerDay}/day</span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button
          className="w-full"
          onClick={() => {
            router.push(`#booking?car=${car.id}`)
          }}
        >
          Book Now
        </Button>
      </CardFooter>
    </Card>
  )
}

