import { Mail, Phone, MapPin } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export function ContactInfo() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Contact Information</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-4">
          <Image
            src="/placeholder.svg?height=80&width=80"
            width={80}
            height={80}
            alt="Owner"
            className="rounded-full"
          />
          <div>
            <h3 className="font-medium">Rajesh Kumar</h3>
            <p className="text-sm text-muted-foreground">Owner & Manager</p>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center">
            <Phone className="h-4 w-4 mr-2" />
            <span>+91 9876543210</span>
          </div>
          <div className="flex items-center">
            <Mail className="h-4 w-4 mr-2" />
            <span>info@hampitours.com</span>
          </div>
          <div className="flex items-start">
            <MapPin className="h-4 w-4 mr-2 mt-1" />
            <span>
              #123, Temple Road, Hampi,
              <br />
              Vijayanagara District,
              <br />
              Karnataka - 583239
            </span>
          </div>
        </div>
        <div className="pt-2">
          <h4 className="font-medium mb-2">Business Hours</h4>
          <p className="text-sm">Monday - Sunday: 6:00 AM - 10:00 PM</p>
        </div>
      </CardContent>
    </Card>
  )
}

